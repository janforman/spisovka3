ALTER TABLE [dokument] CHANGE COLUMN [poradi] [poradi] smallint(6) NOT NULL DEFAULT '1';
