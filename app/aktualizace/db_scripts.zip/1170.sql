
INSERT INTO [:PREFIX:settings] VALUES ('upgrade_needed', 'true');
