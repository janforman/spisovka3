ALTER TABLE [dokument] DROP COLUMN [md5_hash];
