
ALTER TABLE [dokument_historie] DROP FOREIGN KEY [fk_dokument_zmocneni10];
ALTER TABLE [dokument_historie] DROP COLUMN [zmocneni_id];

ALTER TABLE [dokument] DROP COLUMN [zmocneni_id];

DROP TABLE [zmocneni];