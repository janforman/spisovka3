INSERT INTO [settings] VALUES ('spisovna_display_borrowed_documents', 'true');
