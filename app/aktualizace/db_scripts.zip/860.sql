
ALTER TABLE [settings]
  CHANGE COLUMN [value] [value] VARCHAR(2000) NOT NULL;

