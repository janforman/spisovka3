
CREATE INDEX [stav] ON [dokument_odeslani] ([stav]);
