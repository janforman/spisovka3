UPDATE [spisovy_znak] SET [stav] = 0 WHERE [selected] = 0;

ALTER TABLE [spisovy_znak] DROP COLUMN [selected];