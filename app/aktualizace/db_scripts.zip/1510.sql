
CREATE INDEX [sekvence] ON [spis] ([sekvence]);
CREATE INDEX [sekvence] ON [spisovy_znak] ([sekvence]);
