INSERT INTO [settings] VALUES ('epodatelna_auto_load_new_messages', 'true');
