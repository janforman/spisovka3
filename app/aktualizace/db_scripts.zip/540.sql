
ALTER TABLE `user_role` ADD UNIQUE `user_role_code` ( `code` );
