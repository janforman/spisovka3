ALTER TABLE [dokument] DROP COLUMN [spisovy_plan];
