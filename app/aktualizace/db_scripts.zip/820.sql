
ALTER TABLE `file`
  CHANGE COLUMN `mime_type` `mime_type` varchar(100) DEFAULT NULL COMMENT 'mime typ souboru';

