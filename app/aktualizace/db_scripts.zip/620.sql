--  Tento soubor je sloučením více dílčích změn do jednoho souboru;

UPDATE `workflow` SET `aktivni` = 0 WHERE `stav_osoby` >= 100;

-- ----------------------;

DROP TABLE `zprava_osoba`;
DROP TABLE `zprava`;

-- ----------------------;

ALTER TABLE `workflow`
  DROP COLUMN spis_id;

-- ----------------------;

UPDATE `user_resource` SET `name` = 'Epodatelna - zobrazení přílohy' WHERE `name` = 'Epodatelna - zobrazeni prilohy';
UPDATE `user_resource` SET `name` = 'Přílohy' WHERE `name` = 'Prilohy';
UPDATE `user_resource` SET `name` = 'Spisovka - spojení dokumentů' WHERE `name` = 'Spisovka - spojeni dokumentu';
UPDATE `user_resource` SET `name` = 'Vyhledávání' WHERE `name` = 'Vyhledavani';
UPDATE `user_resource` SET `name` = 'Spisovna - vyhledávání' WHERE `name` = 'Spisovna - vyhledavani';
UPDATE `user_resource` SET `name` = 'Spisovna - zápůjčky' WHERE `name` = 'Spisovna - zapujcky';

-- ----------------------;

ALTER TABLE `log_spis`
  DROP FOREIGN KEY `fk_log_spis_spis1`;

ALTER TABLE `log_spis`
  ADD CONSTRAINT `fk_log_spis_spis1` FOREIGN KEY (`spis_id`) REFERENCES `spis` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

-- ----------------------;
  
ALTER TABLE `dokument`
  CHANGE COLUMN `datum_spousteci_udalosti` `datum_spousteci_udalosti` date DEFAULT NULL;
  
UPDATE `dokument` SET datum_spousteci_udalosti = datum_spousteci_udalosti - INTERVAL 1 DAY WHERE datum_spousteci_udalosti LIKE '%-01-01';

-- ----------------------;

ALTER TABLE `dokument_odeslani`
  ADD COLUMN poznamka VARCHAR(200) DEFAULT NULL;
