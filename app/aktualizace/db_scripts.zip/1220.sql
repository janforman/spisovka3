
ALTER TABLE [:PREFIX:dokument] DROP COLUMN [epodatelna_id];
