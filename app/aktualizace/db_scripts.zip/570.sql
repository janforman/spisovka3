
ALTER TABLE `dokument`
  CHANGE COLUMN `nazev` `nazev` varchar(250) NOT NULL;

ALTER TABLE `dokument_historie`
  CHANGE COLUMN `nazev` `nazev` varchar(250) NOT NULL;

UPDATE `user_rule` SET `resource_id` = 23 WHERE `id` = 10;
UPDATE `user_rule` SET `resource_id` = 22 WHERE `id` = 11;
UPDATE `user_rule` SET `resource_id` = 24 WHERE `id` = 12;

UPDATE `file` SET `mime_type` = 'application/xml' WHERE `real_name` LIKE '%.xml';