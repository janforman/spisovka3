
UPDATE `zpusob_odeslani` SET `stav` = 0 WHERE `nazev` = 'telefonicky';
DELETE IGNORE FROM `zpusob_odeslani` WHERE `nazev` = 'telefonicky';

INSERT INTO `zpusob_odeslani` SET `nazev` = 'osobní předání';
