
RENAME TABLE [:PREFIX:workflow] TO [:PREFIX:backup_workflow];
