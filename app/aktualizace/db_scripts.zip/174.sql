-- -----------------------------------------------------------------------------
-- revision 174
--
-- Nahradte rucne  za odpovidajici hodnotu - prefix nebo nic
-- -----------------------------------------------------------------------------;

ALTER TABLE `dokument` ADD `cislo_doporuceneho_dopisu` VARCHAR( 150 ) NULL;
ALTER TABLE `dokument_historie` ADD `cislo_doporuceneho_dopisu` VARCHAR( 150 ) NULL;