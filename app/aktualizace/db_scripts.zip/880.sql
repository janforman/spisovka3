
INSERT INTO [settings] VALUES ('epodatelna_copy_email_into_documents_note', 'true');

INSERT INTO [settings] VALUES ('notification_enabled_receive_document', 'true');
