
CREATE INDEX [stav] ON [zapujcka] ([stav]);
