CREATE INDEX [datum_vzniku] ON [dokument] ([datum_vzniku]);
CREATE INDEX [stav] ON [dokument] ([stav]);
CREATE INDEX [cislo_jednaci] ON [dokument] ([cislo_jednaci]);
