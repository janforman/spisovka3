
ALTER TABLE [:PREFIX:epodatelna] ADD COLUMN [email_signed] BIT(1) DEFAULT NULL;
