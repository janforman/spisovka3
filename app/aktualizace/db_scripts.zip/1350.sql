
UPDATE [zpusob_odeslani] SET [nazev] = 'e-mailem' WHERE [nazev] = 'emailem';