DELETE FROM [acl_resource] WHERE [code] = 'Spisovka_UzivatelPresenter';
DELETE FROM [acl_resource] WHERE [code] = 'Spisovka_DefaultPresenter';
