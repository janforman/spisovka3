
ALTER TABLE [settings] CHANGE [value] [value] varchar(4000) NOT NULL;
