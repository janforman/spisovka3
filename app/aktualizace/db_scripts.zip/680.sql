
INSERT INTO `user_resource` (`code`, `name`) VALUES ('Dokument', 'Dokumenty');
SET @RESOURCE_ID=LAST_INSERT_ID();

INSERT INTO `user_rule` (`resource_id`, `name`, `privilege`) VALUES (@RESOURCE_ID, 'Čtení dokumentů svojí org. jednotky', 'cist_moje_oj');

INSERT INTO `user_acl` (`role_id`, `rule_id`, `allowed`) VALUES ((SELECT `id` FROM `user_role` WHERE `code` = 'referent'), LAST_INSERT_ID(), 'Y');

INSERT INTO `user_rule` (`resource_id`, `name`, `privilege`) VALUES (@RESOURCE_ID, 'Čtení všech dokumentů', 'cist_vse');
INSERT INTO `user_rule` (`resource_id`, `name`, `privilege`) VALUES (@RESOURCE_ID, 'Změny dokumentů svojí org. jednotky', 'menit_moje_oj');

-- ----------------------;

ALTER TABLE `sestava` ADD COLUMN zobrazeni_dat TEXT NULL DEFAULT NULL;

-- ----------------------;

UPDATE `user_role` SET `order` = NULL;

-- ----------------------;

ALTER TABLE `orgjednotka` DROP COLUMN uroven;
ALTER TABLE `spis` DROP COLUMN uroven;
ALTER TABLE `spisovy_znak` DROP COLUMN uroven;
ALTER TABLE `user_role` DROP COLUMN uroven;

