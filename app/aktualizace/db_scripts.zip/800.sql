
UPDATE `subjekt` SET stav = 2 WHERE stav <> 1;
