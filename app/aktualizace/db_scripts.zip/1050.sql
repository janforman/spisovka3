UPDATE [:PREFIX:spis] SET [typ] = 'F' WHERE [typ] = 'VS';
