
ALTER TABLE [:PREFIX:epodatelna] DROP COLUMN [sha1_hash];
