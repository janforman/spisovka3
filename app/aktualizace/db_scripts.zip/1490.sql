ALTER TABLE [log_access]
    CHANGE COLUMN [ip] [ip] varchar(50) ascii DEFAULT NULL;