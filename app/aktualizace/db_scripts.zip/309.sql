-- -----------------------------------------------------------------------------
-- revision 309
--
-- Nahradte rucne  za odpovidajici hodnotu - prefix nebo nic
-- -----------------------------------------------------------------------------;

ALTER TABLE `dokument` CHANGE `popis` `popis` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL;
ALTER TABLE `dokument_historie` CHANGE `popis` `popis` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL;