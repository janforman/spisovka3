
SET FOREIGN_KEY_CHECKS=0;

ALTER TABLE `dokument_historie`
  DROP FOREIGN KEY `fk_dokument_historie_dokument1`;
ALTER TABLE `dokument_historie`
  ADD CONSTRAINT `fk_dokument_historie_dokument1` FOREIGN KEY (`dokument_id`) REFERENCES `dokument` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

ALTER TABLE `dokument_odeslani`
  DROP FOREIGN KEY `fk_dokument_odeslani_dokument1`;
ALTER TABLE `dokument_odeslani`
  ADD CONSTRAINT `fk_dokument_odeslani_dokument1` FOREIGN KEY (`dokument_id`) REFERENCES `dokument` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

ALTER TABLE `dokument_to_file`
  DROP FOREIGN KEY `fk_dokument_to_file_dokument1`;
ALTER TABLE `dokument_to_file`
  ADD CONSTRAINT `fk_dokument_to_file_dokument1` FOREIGN KEY (`dokument_id`) REFERENCES `dokument` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
  
ALTER TABLE `dokument_to_spis`
  DROP FOREIGN KEY `fk_dokument_to_spis_dokument1`;
ALTER TABLE `dokument_to_spis`
  ADD CONSTRAINT `fk_dokument_to_spis_dokument1` FOREIGN KEY (`dokument_id`) REFERENCES `dokument` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

ALTER TABLE `dokument_to_subjekt`
  DROP FOREIGN KEY `fk_dokument_to_subjekt_dokument1`;
ALTER TABLE `dokument_to_subjekt`
  ADD CONSTRAINT `fk_dokument_to_subjekt_dokument1` FOREIGN KEY (`dokument_id`) REFERENCES `dokument` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

ALTER TABLE `epodatelna`
  DROP FOREIGN KEY `fk_epodatelna_dokument1`;
ALTER TABLE `epodatelna`
  ADD CONSTRAINT `fk_epodatelna_dokument1` FOREIGN KEY (`dokument_id`) REFERENCES `dokument` (`id`) ON DELETE SET NULL ON UPDATE NO ACTION;

ALTER TABLE `log_dokument`
  DROP FOREIGN KEY `fk_log_dokument_dokument1`;
ALTER TABLE `log_dokument`
  ADD CONSTRAINT `fk_log_dokument_dokument1` FOREIGN KEY (`dokument_id`) REFERENCES `dokument` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

ALTER TABLE `souvisejici_dokument`
  DROP FOREIGN KEY `fk_souvisejici_dokument_dokument1`,
  DROP FOREIGN KEY `fk_souvisejici_dokument_dokument2`;
ALTER TABLE `souvisejici_dokument`
  ADD CONSTRAINT `fk_souvisejici_dokument_dokument1` FOREIGN KEY (`dokument_id`) REFERENCES `dokument` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_souvisejici_dokument_dokument2` FOREIGN KEY (`spojit_s_id`) REFERENCES `dokument` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

ALTER TABLE `workflow`
  DROP FOREIGN KEY `fk_workflow_dokument1`;  
ALTER TABLE `workflow`
  ADD CONSTRAINT `fk_workflow_dokument1` FOREIGN KEY (`dokument_id`) REFERENCES `dokument` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

SET FOREIGN_KEY_CHECKS=1;