-- -----------------------------------------------------------------------------
-- revision 321
--
-- Nahradte rucne  za odpovidajici hodnotu - prefix nebo nic
-- -----------------------------------------------------------------------------;

ALTER TABLE `spisovy_znak` ADD `selected` TINYINT( 1 ) UNSIGNED NOT NULL DEFAULT '1';