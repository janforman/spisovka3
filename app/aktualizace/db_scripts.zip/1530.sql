
UPDATE [dokument] SET [forward_user_id] = NULL, [forward_orgunit_id] = NULL WHERE NOT [is_forwarded];