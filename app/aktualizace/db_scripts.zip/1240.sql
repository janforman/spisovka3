
ALTER TABLE [:PREFIX:file] DROP COLUMN [real_type];