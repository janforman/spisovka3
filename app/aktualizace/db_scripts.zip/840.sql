
DELETE FROM [user_resource] WHERE [code] = 'Spisovka_NapovedaPresenter';
