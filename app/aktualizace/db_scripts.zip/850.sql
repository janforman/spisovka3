
ALTER TABLE [user_settings]
  CHANGE COLUMN [settings] [settings] VARCHAR(5000) NOT NULL;
